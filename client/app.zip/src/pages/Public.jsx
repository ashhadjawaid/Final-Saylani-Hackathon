import React from 'react'

const Public = () => {
  return (
    <h1>This Page Doesnt Exits</h1>
  )
}

export default Public